namespace NathanLoggingSystem_API.Interfaces
{
    public interface IGetLogger
    {
        string GetLog();
    }
}