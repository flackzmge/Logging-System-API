using NathanLoggingSystem_API.Classes;

namespace NathanLoggingSystem_API.Interfaces;
public interface ILogger
{
    void WriteLog(string message);
}

public class FileLogger : ILogger, IGetLogger
{
    private readonly string _logFilePath;

    public FileLogger(string logFilePath)
    {
        _logFilePath = logFilePath;
    }

    public void WriteLog(string message)
    {
        // C# create Log file - give a path and write the message
        using (var streamWriter = new StreamWriter(_logFilePath, true))
        {
            streamWriter.WriteLine(DateTime.Now + ": " + message);
        }

        Console.WriteLine("FileLogger: " + message);
    }
    
    public string GetLog()
    {
        // Read the log file and return the contents as a string
        using (var streamReader = new StreamReader(_logFilePath))
        {
            return streamReader.ReadToEnd();
        }
    }
}


