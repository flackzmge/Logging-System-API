﻿using NathanLoggingSystem_API.Interfaces;
using Microsoft.AspNetCore.Mvc;
//using LoggingSystem.Interfaces;
using ILogger = NathanLoggingSystem_API.Interfaces.ILogger;
//using LoggerFactory = NathanLoggingSystem_API.Classes.LoggerFactory;


namespace NathanLoggingSystem_API.Controllers;

[ApiController]
[Route("[controller]")]


public class LogController : Controller
{
    //private readonly LoggerFactory _loggerFactory;

    public LogController(LoggerFactory loggerFactory)
    {
        //_loggerFactory = loggerFactory;
    }
    
    [HttpPost]
    public IActionResult WriteLog(string type, string filePath, string message)
    {
        // Create an ILogger instance using the LoggerFactory and the file path
        //ILogger logger = _loggerFactory.CreateLogger(type, filePath);

        // Write the log message using the ILogger instance
        //logger.WriteLog(message);

        return Ok();
    }
    
    [HttpGet]
    public IActionResult GetLog(string type, string filePath)
    {
        // Create an IGetLogger instance using the LoggerFactory and the file path
        //IGetLogger getLogger = _loggerFactory.CreateGetLogger(type, filePath);

        // Get the log messages using the IGetLogger instance
        //string logMessages = getLogger.GetLog();

        //return Json(logMessages);
        return Ok();
    }


}

// Return in JSON format the log messages
/*  // Create a FileLogger instance using the LoggerFactory
        ILogger fileLogger = loggerFactory.CreateLogger("file", "/Users/nathangilbert/Logs/Hello.txt");
        // write a log message to the file
        fileLogger.WriteLog("Hello World");
        IGetLogger fileGetLogger = loggerFactory.CreateGetLogger("file", "/Users/nathangilbert/Logs/Hello.txt");
 */


/*public static void Main(string[] args)
    {
        
        // Create an instance of the LoggerFactory class
        var loggerFactory = new LoggerFactory();

        // Create a FileLogger instance using the LoggerFactory
        ILogger fileLogger = loggerFactory.CreateLogger("file", "/Users/nathangilbert/Logs/Hello.txt");
        // write a log message to the file
        fileLogger.WriteLog("Hello World");
        IGetLogger fileGetLogger = loggerFactory.CreateGetLogger("file", "/Users/nathangilbert/Logs/Hello.txt");

        string logMessages = fileGetLogger.GetLog();
        Console.WriteLine(logMessages);
        // Write a log message using the FileLogger instance
        //fileLogger.WriteLog("This is a log message from the FileLogger");

        // Create an instance of the DatabaseLogger class and pass in the connection string
        //ILogger databaseLogger = new DatabaseLogger("Server=localhost;Database=Logging;Trusted_Connection=True;");
        // Write a log message using the DatabaseLogger instance
        //databaseLogger.WriteLog("This is a log message from the DatabaseLogger");
    
    } */
    
    

    
    