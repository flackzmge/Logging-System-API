using NathanLoggingSystem_API.Interfaces;
using ILogger = NathanLoggingSystem_API.Interfaces.ILogger;

namespace NathanLoggingSystem_API.Classes;

public class Logger : ILogger
{
    private readonly ILogger _logger;

    public Logger(ILogger logger)
    {
        _logger = logger;
    }

    public void WriteLog(string message)
    {
        _logger.WriteLog(message);
    }

    public void Log(string thisIsATestMessage)
    {
        throw new NotImplementedException();
    }
}
